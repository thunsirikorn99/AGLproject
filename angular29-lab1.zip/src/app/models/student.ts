export class Student {
}
