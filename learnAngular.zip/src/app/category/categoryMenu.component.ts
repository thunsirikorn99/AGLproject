import { Component } from '@angular/core';

@Component({
selector: 'app-category',
templateUrl: './categoryMenu.component.html',
styleUrls: ['./categoryMenu.component.css']
})

export class CategoryMenuComponent {

    constructor() {};

}
