import { Component } from '@angular/core';

@Component({
selector: 'app-topbanner',
templateUrl: './topbanner.component.html',
styleUrls: ['./topbanner.component.css']
})

export class TopbannerComponent {

    constructor() {};

}
